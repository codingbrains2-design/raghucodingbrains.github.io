<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('register','Auth\RegisterController@create');
Route::post('contact_us', 'ContactUsController@store');

Route::resource(
    'company',
    'CompanyController',
    ['only' => ['index', 'store', 'show', 'update']]
);

Route::resource(
    'userdetails',
    'UserDetailController',
    ['only' => ['index', 'store', 'show']]
);
Route::resource(
    'blog',
    'BlogController',
    ['only' => ['index', 'store', 'show', 'update']]
);
Route::resource(
    'usereducation',
    'UserEducationController',
    ['only' => ['index', 'store', 'show', 'update', 'destroy']]
);
Route::resource(
    'userexperience',
    'UserExperienceController',
    ['only' => ['index', 'store', 'update', 'destroy']]
);
Route::resource(
    'job',
    'JobController',
    ['only' => ['index', 'store', 'show', 'update', 'destroy']]
);

Route::group(['prefix' => 'job/{job_guid}'], function () {
    Route::get('applications', 'JobController@getApplications');
    Route::post('companyApply', 'ApplicationController@companyApply');
    Route::post('userApply', 'ApplicationController@userApply');
});

Route::group(['prefix' => 'application/{application_guid}'], function () {
    Route::patch('employerApproval', 'ApplicationController@employerApproval');
    Route::patch('applicantApproval', 'ApplicationController@applicantApproval');
});

Route::resource(
    'application',
    'ApplicationController',
    ['only' => ['update', 'destroy']]
);
