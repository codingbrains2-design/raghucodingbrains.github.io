<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{

    protected $table = 'companies';

    protected $fillable = ['company_guid', 'company_code', 'company_name', 'company_website',
        'company_description', 'created_by', 'is_searchable', 'contact', 'is_employer', 'available'];

    protected $hidden = ['id', 'created_by', 'created_at', 'updated_at', 'deleted_at'];

    protected $dates = ['created_at', 'updated_at', 'deleted_at'];

    public function users()
    {
        return $this->belongsToMany('App\User')->withPivot('designation', 'role', 'employee_id');
    }

    public function postedJobs()
    {
        return $this->hasMany('App\Job', 'created_by');
    }

    public function acceptedJobs()
    {
        return $this->MorphToMany('App\Job', 'contractor', 'contracts');
    }

    public function locations()
    {
        return $this->morphToMany('App\Location', 'location_mappable', 'location_maps');
    }

    public function competencies()
    {
        return $this->morphToMany('App\Competency', 'competency_mappable', 'competency_maps');
    }

    public function behaviours()
    {
        return $this->morphToMany('App\Behaviour', 'behaviour_mappable', 'behaviours_maps');
    }

    public function industries()
    {
        return $this->morphToMany('App\Industry', 'industry_mappable', 'industry_maps');
    }

    public function plan()
    {
        return $this->belongsTo('App\Plan');
    }

    public function toArray()
    {
        $attributes = $this->attributesToArray();
        $attributes = array_merge($attributes, $this->relationsToArray());
        if (isset($attributes['pivot'])) {
            foreach (array_keys($attributes['pivot']) as $key) {
                if (strpos($key, '_id') !== false && $key != 'employee_id') {
                    unset($attributes['pivot'][$key]);
                }
            }
        }
        if (isset($attributes['users'])) {
            foreach ($attributes['users'] as $key => $user) {
                unset($user['pivot']['user_id']);
                unset($user['pivot']['company_id']);
                $attributes['users'][$key] = $user;
            }
        }
        return $attributes;
    }
}
