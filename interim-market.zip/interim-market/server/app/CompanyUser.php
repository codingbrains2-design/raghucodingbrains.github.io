<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompanyUser extends Model
{

    protected $table = 'company_user';

    protected $fillable = ['user_id', 'company_id', 'employee_id', 'designation',
        'role', 'invitation_status'];

    protected $hidden = ['user_id', 'company_id', 'employee_id', 'invitation_status'];
}
