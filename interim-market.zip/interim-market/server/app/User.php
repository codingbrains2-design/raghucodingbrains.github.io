<?php

namespace App;

use Laravel\Passport\HasApiTokens;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable;

    protected $table = 'users';

    protected $fillable = ['user_guid', 'linkedin_id', 'email', 'password', 'first_name', 'last_name', 'im_superuser',
        'im_staff', 'hash', 'is_verified', 'is_active', 'is_blocked', 'default_company', 'is_searchable',
        'remember_token'];

    protected $hidden = ['id', 'linkedin_id', 'password', 'is_verified', 'is_active', 'is_searchable',
        'remember_token'];

    protected $dates = ['created_at', 'updated_at'];

    public function userDetail()
    {
        return $this->hasOne('App\UserDetail');
    }

    public function companies()
    {
        return $this->belongsToMany('App\Company')->withPivot('designation', 'role', 'employee_id');
    }

    public function defaultCompany()
    {
        return $this->belongsTo('App\Company', 'default_company');
    }

    public function contracts()
    {
        return $this->MorphToMany('App\Job', 'contractor', 'contracts');
    }

    public function industries()
    {
        return $this->morphToMany('App\Industry', 'industry_mappable', 'industry_maps');
    }

    public function locations()
    {
        return $this->morphToMany('App\Location', 'location_mappable', 'location_maps');
    }

    public function competencies()
    {
        return $this->morphToMany('App\Competency', 'competency_mappable', 'competency_maps');
    }

    public function behaviours()
    {
        return $this->morphToMany('App\Behaviour', 'behaviour_mappable', 'behaviours_maps');
    }

    public function plan()
    {
        return $this->morphToMany('App\Plan', 'plan_mappable', 'plan_maps');
    }

    public function userEducation()
    {
        return $this->hasMany('App\UserEducation');
    }

    public function userExperience()
    {
        return $this->hasMany('App\UserExperience');
    }

    public function toArray()
    {
        $attributes = $this->attributesToArray();
        $attributes = array_merge($attributes, $this->relationsToArray());
        if (isset($attributes['pivot'])) {
            foreach (array_keys($attributes['pivot']) as $key) {
                if (strpos($key, '_id') !== false && $key != 'employee_id') {
                    unset($attributes['pivot'][$key]);
                }
            }
        }

        if (isset($attributes['companies'])) {
            foreach ($attributes['companies'] as $key => $company) {
                unset($company['pivot']['user_id']);
                unset($company['pivot']['company_id']);
                $attributes['companies'][$key] = $company;
            }
        }
        return $attributes;
    }
}
