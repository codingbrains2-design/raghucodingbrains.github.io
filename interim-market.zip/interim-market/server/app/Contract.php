<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Contract extends Model
{
    use SoftDeletes;

    protected $table = 'contracts';

    protected $fillable = ['contract_guid', 'contractor_id', 'contractor_type',
        'job_id', 'start_date', 'end_date', 'currency', 'contract_rate', 'payment_frequency'];

    protected $hidden = ['id', 'contractor_id', 'contractor_type', 'job_id'];
}
