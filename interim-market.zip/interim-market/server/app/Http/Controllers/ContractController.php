<?php

namespace App\Http\Controllers;

use App\Application;
use App\Company;
use App\Contract;
use App\Job;
use Illuminate\Http\Request;
use Faker;

class ContractController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    public static function store(Application $application)
    {
        $internals = Faker\Factory::create('en_US');
        $contract = Contract::create([
            'contract_guid' => $internals->uuid,
            'contractor_id' => $application['applicant_id'],
            'contractor_type' => $application['applicant_type'],
            'job_id' => $application['job_id'],
            'start_date' => $application['proposed_start_date'],
            'end_date' => $application['proposed_end_date'],
            'currency' => $application['currency'],
            'contract_rate' => $application['proposed_contract_rate'],
            'payment_frequency' => $application['payment_frequency']
        ]);
        return $contract;
    }
}
