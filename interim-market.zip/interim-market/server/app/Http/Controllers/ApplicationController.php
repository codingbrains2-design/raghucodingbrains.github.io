<?php

namespace App\Http\Controllers;

use App\Application;
use App\Company;
use App\Job;
use Illuminate\Support\Facades\Gate;
use Illuminate\Http\Request;
use Faker;

class ApplicationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    public function update(Request $request, $application_guid)
    {
        $user = \Auth::user();
        $application = Application::where('application_guid', $application_guid)->first();
        if ($user->can('update', $application)) {
            if ($application['applicant_approval'] === 'pending' && $application['employer_approval'] === 'pending') {
                $application->update([
                    'proposed_start_date'=> $request['proposed_start_date'],
                    'proposed_end_date' => $request['proposed_end_date'],
                    'currency' => $request['currency'],
                    'proposed_contract_rate' => $request['proposed_contract_rate'],
                    'payment_frequency' => $request['payment_frequency']
                ]);
                return response()->json(compact('application', 200));
            } else {
                return response()->json(['Error' => 'Application cannot be updated post approval from a party'], 400);
            }
        } else {
            return response()->json(['Unauthorized'], 401);
        }
    }

    public function destroy($application_guid)
    {
        $application = Application::where('application_guid', $application_guid)->first();
        if ($application) {
            $application->delete();
            return response()->json(['Success' => 'Application deleted successfully'], 200);
        }
        return response()->json(['Error' => 'Application does not exist'], 400);
    }

    public function userApply(Request $request, $job_guid)
    {
        $job = Job::where('job_guid', $job_guid)->first();
        $user = \Auth::user();
        $internals = Faker\Factory::create('en_US');
        $application = [
            'application_guid' => $internals->uuid,
            'proposed_start_date' => $request['proposed_start_date'],
            'proposed_end_date' => $request['proposed_end_date'],
            'employer_approval' => 'pending',
            'applicant_approval' => 'pending',
            'currency' => $request['currency'],
            'proposed_contract_rate' => $request['proposed_contract_rate'],
            'payment_frequency' => $request['payment_frequency']
        ];
        $job->userApplications()->attach($user['id'], $application);
        return response()->json(compact('application'), 200);
    }

    public function companyApply(Request $request, $job_guid)
    {
        $user = \Auth::user();
        $job = Job::where('job_guid', $job_guid)->first();
        $appliedCompany = $job->companyApplications()->where('company_guid', $request['company_guid'])->first();
        if ($appliedCompany) {
            return response()->json(['error' => 'Already applied for the job'], 400);
        }

        $company = Company::where('company_guid', $request['company_guid'])->first();
        if ($user->can('applyForCompany', $company)) {
            $internals = Faker\Factory::create('en_US');
            $application = [
                'application_guid' => $internals->uuid,
                'proposed_start_date' => $request['proposed_start_date'],
                'proposed_end_date' => $request['proposed_end_date'],
                'employer_approval' => 'pending',
                'applicant_approval' => 'pending',
                'currency' => $request['currency'],
                'proposed_contract_rate' => $request['proposed_contract_rate'],
                'payment_frequency' => $request['payment_frequency']
            ];
            $job->companyApplications()->attach($company['id'], $application);
            return response()->json(compact('application'), 200);
        } else {
            return response()->json(['Unauthorized'], 401);
        }
    }

    public function employerApproval(Request $request, $application_guid)
    {
        $user = \Auth::user();
        $application = Application::where('application_guid', $application_guid)->first();
        if ($application['employer_approval'] !== 'pending') {
            return response()->json(['Error' => 'Already '.$application['employer_approval']], 400);
        }
        if ($user->can('updateEmployerApproval', $application)) {
            $application->update([
                'employer_approval' => $request['approval']
            ]);
        } else {
            return response()->json(['Error' => 'Unauthorized'], 401);
        }

        if ($application['applicant_approval'] === 'approved' && $application['employer_approval'] === 'approved') {
            $contract = ContractController::store($application);
            return response()->json(compact('application', 'contract'), 200);
        }
        return response()->json(compact('application'), 200);
    }

    public function applicantApproval(Request $request, $application_guid)
    {
        $user = \Auth::user();
        $application = Application::where('application_guid', $application_guid)->first();
        if ($application['applicant_approval'] !== 'pending') {
            return response()->json(['Error' => 'Already '.$application['applicant_approval']], 400);
        }
        if ($user->can('updateApplicantApproval', $application)) {
            $application->update([
                'applicant_approval' => $request['approval']
            ]);
        } else {
            return response()->json(compact('allowed', 'application'), 401);
        }
        if ($application['applicant_approval'] === 'approved' && $application['employer_approval'] === 'approved') {
            $contract = ContractController::store($application);
            return response()->json(compact('application', 'contract'), 200);
        }
        return response()->json(compact('application'), 200);
    }
}
