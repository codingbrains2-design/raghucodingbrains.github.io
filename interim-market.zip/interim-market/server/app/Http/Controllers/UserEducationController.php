<?php

namespace App\Http\Controllers;

use App\UserEducation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Faker;

class UserEducationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $userEducation = \Auth::user()->userEducation()->get();
        return response()->json(compact('userEducation'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $internals = Faker\Factory::create('en_US');
        $user = \Auth::user();

        $userEducation = UserEducation::create([
            'user_education_guid' => $internals->uuid,
            'user_id' => $user->id,
            'school' => $request['school'],
            'degree' => $request['degree'],
            'grades' => $request['grades'],
            'start_date' => $request['start_date'],
            'end_date' => $request['end_date']
        ]);

        return response()->json(compact('userEducation'), 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  string  $user_education_guid
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $user_education_guid)
    {
        $updated_userEducation = [
            'school' => $request['school'],
            'degree' => $request['degree'],
            'grades' => $request['grades'],
            'start_date' => $request['start_date'],
            'end_date' => $request['end_date']
        ];

        $update_status = UserEducation::where('user_education_guid', $user_education_guid)
            ->update($updated_userEducation);

        if ($update_status) {
            return response()->json(compact('userEducation'), 201);
        } else {
            return response()->json(['error' => 'something went wrong'], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $user_education_guid
     * @return \Illuminate\Http\Response
     */
    public function destroy($user_education_guid)
    {
        $userEducation = UserEducation::where('user_education_guid', $user_education_guid)->first();
        if ($userEducation['user_id'] !== \Auth::user()['id']) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }
        $userEducation->delete();
        return response()->json(['success' => 'Education entry deleted'], 200);
    }
}
