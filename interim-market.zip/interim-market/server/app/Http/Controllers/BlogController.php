<?php

namespace App\Http\Controllers;

use App\Blog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Faker;
use Illuminate\Support\Facades\Input;

class BlogController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $page = $request->get('page', 1);
        $skip = ($page - 1) * 10 + $request->get('skip', 0);
        $blogs = Blog::with('user')->orderBy('created_at', 'DESC')
            ->skip($skip)->take(10)->get();
        $total = Blog::count();
        $nextPage = $page + 1;
        $query_params = array_merge(Input::except(['page', 'skip']), ['page' => $nextPage]);
        $next_page_url = ($nextPage - 1) * 10 < $total ?
            $request->url() . "?" . http_build_query($query_params) : null;

        return response()->json(compact('total', 'next_page_url', 'blogs'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $internals = Faker\Factory::create('en_US');
        $blog = Blog::create([
            'blog_guid' => $internals->uuid,
            'user_id' => \Auth::user()['id'],
            'title' => $request['title'],
            'blog' => $request['blog'],
            'slug' =>$request['slug'],
            'is_active' => $request['is_active'],
            'published_at' => ($request['is_active']? date('Y-m-d H:i:s'): null)

            // Todo: facebook and twitter details
        ]);

        return response()->json(compact('blog'), 201);
    }

    public function show($blog_guid)
    {
        $blog = Blog::where('blog_guid', $blog_guid)->with('user')->first();
        return response()->json(compact('blog'), 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  string  $blog_guid
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $blog_guid)
    {
        $blog = Blog::where('blog_guid', $blog_guid)->first();

        $update_status = $blog->update([
            'title' => $request['title'],
            'blog' => $request['blog'],
            'is_active' => $request['is_active'],
            'published_at' => ($request['is_active']? date('Y-m-d H:i:s'): null)
        ]);

        if ($update_status) {
            return response()->json(compact('blog'), 201);
        } else {
            return response()->json(['error' => 'something went wrong'], 400);
        }
    }
}
