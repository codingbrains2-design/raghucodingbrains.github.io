<?php

namespace App\Http\Controllers;

use App\Competency;
use Illuminate\Http\Request;
use Faker;

class CompetencyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $competencies = Competency::where('is_approved', true)->get();
        return response()->json(compact('competencies'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  array $data
     * @return \Illuminate\Http\Response
     */
    public static function store(array $data)
    {
        $internals = Faker\Factory::create('en_US');
        $competency = Competency::create([
            'name' => $data['name'],
            'is_approved' => false,
            'competency_guid' => $internals->uuid,
        ]);

        return $competency;
    }
}
