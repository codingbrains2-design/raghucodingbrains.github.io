<?php

namespace App\Http\Controllers;

use App\Industry;
use Illuminate\Http\Request;
use Faker;

class IndustryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $industries = Industry::where('is_approved', true)->get();
        return response()->json(compact('industries'));
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  array  $data
     * @return \Illuminate\Http\Response
     */
    public static function store(array $data)
    {
        $internals = Faker\Factory::create('en_US');
        $industry = Industry::create([
            'name' => $data['name'],
            'is_approved' => false,
            'industry_guid' => $internals->uuid,
        ]);

        return $industry;
    }
}
