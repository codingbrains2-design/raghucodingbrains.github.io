<?php

namespace App\Http\Controllers;

use App\ContactUs;
use Illuminate\Http\Request;
use Faker;

class ContactUsController extends Controller
{

    public function store(Request $request)
    {
        $contact_us = ContactUs::create([
            'name' => $request['name'],
            'email' => $request['email'],
            'query_type' =>$request['query_type'],
            'description' => $request['description']
        ]);

        return response()->json(compact('contact_us'), 201);
    }
}
