<?php

namespace App\Http\Controllers;

use App\Company;
use App\Competency;
use App\Industry;
use App\Location;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Faker;

class CompanyController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $companies = \Auth::user()->companies()->get();
        return response()->json(compact('companies'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $internals = Faker\Factory::create('en_US');
        $user = \Auth::user();
        $company = Company::create([
           'company_guid' => $internals->uuid,
            'created_by' => $user->id,
            'company_code' => $request['company_code'],
            'company_name' => $request['company_name'],
            'company_website' => $request['company_website'],
            'company_description' => $request['company_description'],
            'contact' => $request['contact'],
            'is_employer' => $request['is_employer'],
            'is_searchable' => $request['is_searchable'],
            'available' => $request['available']
        ]);

        $this->attachCompanyDetails($company, $request);
        $user->companies()->attach($company['id'], ['role' => 'superuser', 'invitation_status' => 'accepted']);
        return response()->json(compact('company'), 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  string  $company_guid
     * @return \Illuminate\Http\Response
     */
    public function show($company_guid)
    {
        $company = Company::where('company_guid', $company_guid)
            ->with('locations', 'competencies', 'industries')->first();
        return response()->json(compact('company'), 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  string  $company_guid
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $company_guid)
    {
        $updated_company = [
            'company_website' => $request['company_website'],
            'company_description' => $request['company_description'],
            'contact' => $request['contact'],
            'is_employer' => $request['is_employer'],
            'is_searchable' => $request['is_searchable'],
            'available' => $request['available']
        ];
        $company = Company::where('company_guid', $company_guid)->first();
        $company->competencies()->detach();
        $company->industries()->detach();
        $company->locations()->detach();
        $this->attachCompanyDetails($company, $request);

        $update_status = $company->update($updated_company);

        if ($update_status) {
            return response()->json(compact('company'), 201);
        } else {
            return response()->json(['error' => 'something went wrong'], 400);
        }
    }

    private function attachCompanyDetails($company, $request)
    {
        if ($request['locations']) {
            foreach ($request['locations'] as $location_guid) {
                $location = Location::where('location_guid', $location_guid)->first();
                $company->locations()->attach($location);
            }
        }

        if ($request['industries']) {
            foreach ($request['industries'] as $industry_guid) {
                $industry = Industry::where('industry_guid', $industry_guid)->first();
                if (!$industry) {
                    $industry = IndustryController::store(['name' => $industry_guid]);
                }
                $company->industries()->attach($industry);
            }
        }

        if ($request['competencies']) {
            foreach ($request['competencies'] as $competency_guid) {
                $competency = Competency::where('competency_guid', $competency_guid)->first();
                if (!$competency) {
                    $competency = CompetencyController::store(['name' => $competency_guid]);
                }
                $company->competencies()->attach($competency);
            }
        }
    }
}
