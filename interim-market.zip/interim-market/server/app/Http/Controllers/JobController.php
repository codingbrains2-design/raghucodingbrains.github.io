<?php

namespace App\Http\Controllers;

use App\Company;
use App\Competency;
use App\Job;
use App\Location;
use App\Policies\Helper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Faker;
use Illuminate\Support\Facades\DB;

class JobController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $page = $request->get('page', 1);
        $skip = ($page - 1) * 10 + $request->get('skip', 0);
        $jobQuery = $this->jobQueryBuilder($request);
        $openJobs = $jobQuery->orderBy('created_at', 'DESC')
            ->skip($skip)->take(10)->get();
        $total = $this->jobQueryBuilder($request)->count();
        $nextPage = $page + 1;
        $query_params = array_merge(Input::except(['page', 'skip']), ['page' => $nextPage]);
        $next_page_url = ($nextPage - 1) * 10 < $total ?
            $request->url() . "?" . http_build_query($query_params) : null;

        return response()->json(compact('total', 'next_page_url', 'openJobs'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Todo Authorization check
        $internals = Faker\Factory::create('en_US');
        $location = Location::where('location_guid', $request['location_guid'])->first();
        $competency_ids = Competency::whereIn('competency_guid', $request['competency_guids'])
            ->pluck('id');
        $company = Company::where('company_guid', $request['company_guid'])->first();
        if ($location === null || count($competency_ids) !== count($request['competency_guids'])) {
            return response()->json(['error' => 'Location or Competency provided, does not exist.'], 400);
        }
        $job = Job::create([
            'job_guid' => $internals->uuid,
            'job_heading' => $request['job_heading'],
            'job_description' => $request['job_description'],
            'status' => 'open',
            'currency' => $request['currency'],
            'salary_start' => $request['salary_start'],
            'salary_end' => $request['salary_end'],
            'location_id' => $location['id'],
            'employer_id' => $company['id'],
            'created_by' => \Auth::user()->id
        ]);
        $job->competencies()->attach($competency_ids);
        $job->load('location', 'competencies', 'employer');
        return response()->json(compact('job'), 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  string  $job_guid
     * @return \Illuminate\Http\Response
     */
    public function show($job_guid)
    {
        $job = Job::where('job_guid', $job_guid)
            ->with('contractUsers', 'contractCompanies', 'location', 'competencies', 'employer')->first();
        return response()->json(compact('job'), 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  string  $job_guid
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $job_guid)
    {
        $job = Job::where('job_guid', $job_guid)->first();
        if ($job['status'] != 'open') {
            return response()->json(['Accepted jobs cannot be updated'], 400);
        }

        $location = Location::where('location_guid', $request['location_guid'])->first();
        $competency_ids = Competency::whereIn('competency_guid', $request['competency_guids'])
            ->pluck('id');

        if ($location === null || count($competency_ids) !== count($request['competency_guids'])) {
            return response()->json(['error' => 'Location or Competency provided, does not exist.'], 400);
        }

        $job->update([
            'job_heading' => $request['job_heading'],
            'job_description' => $request['job_description'],
            'location->id' => $location['id'],
        ]);

        $job->competencies()->detach();
        $job->competencies()->attach($competency_ids);

        $job->load('location', 'competencies');
        return response()->json(compact('job'), 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $job_guid
     * @return \Illuminate\Http\Response
     */
    public function destroy($job_guid)
    {
        $job = Job::where('job_guid', $job_guid)->first();
        $job->contract()->detach();
        $deletedRows = $job->delete();

        if ($deletedRows == 0) {
            return response()->json(['Success' => 'Job deleted successfully'], 200);
        } else {
            return response()->json(['Error' => 'Job doesn\'t exist'], 400);
        }
    }

    public function getAcceptedJobs(Request $request)
    {
        $acceptedJobs = Company::where('company_guid', $request['company_guid'])->first()->acceptedJobs()->get();
        return response()->json(compact('acceptedJobs'), 200);
    }

    public function getApplications($job_guid)
    {
        $job = Job::where('job_guid', $job_guid)->with('userApplications', 'companyApplications')->first();
        return response()->json(compact('job'), 200);
    }

    private function jobQueryBuilder(Request $request)
    {
        $jobQuery = Job::where('status', 'open');

        if ($request['location_guids']) {
            $location_guids = explode(',', $request['location_guids']);
            $jobQuery = $jobQuery->whereHas('location', function ($location) use ($location_guids) {
                $location->whereIn('location_guid', $location_guids);
            });
        }

        if ($request['competency_guids']) {
            $competency_guids = explode(',', $request['competency_guids']);
            $jobQuery = $jobQuery->whereHas('competencies', function ($competency) use ($competency_guids) {
                $competency->whereIn('competency_guid', $competency_guids);
            });
        }

        if ($request['search_text']) {
            $jobQuery = $jobQuery->where(function ($subQuery) use ($request) {
                $subQuery->where('job_heading', 'like', '%' . $request['search_text'] . '%')
                    ->orWhere('job_description', 'like', '%' . $request['search_text'] . '%');
            });
        }
        return $jobQuery;
    }
}
