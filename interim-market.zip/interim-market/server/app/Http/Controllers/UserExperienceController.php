<?php

namespace App\Http\Controllers;

use App\UserExperience;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Faker;

class UserexperienceController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $userExperience = \Auth::user()->userExperience()->get();
        return response()->json(compact('userExperience'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $internals = Faker\Factory::create('en_US');
        $user = \Auth::user();

        $userExperience = UserExperience::create([
            'user_experience_guid' => $internals->uuid,
            'user_id' => $user->id,
            'job_position' => $request['job_position'],
            'company_name' => $request['company_name'],
            'job_status' => $request['job_status'],
            'achievements' => $request['achievements'],
            'start_date' => $request['start_date'],
            'end_date' => $request['end_date']
        ]);

        return response()->json(compact('userExperience'), 201);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  string  $user_experience_guid
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $user_experience_guid)
    {

        $updated_userExperience = [
            'job_position' => $request['job_position'],
            'company_name' => $request['company_name'],
            'job_status' => $request['job_status'],
            'achievements' => $request['achievements'],
            'start_date' => $request['start_date'],
            'end_date' => $request['end_date']
        ];

        $update_status = UserExperience::where('user_experience_guid', $user_experience_guid)
            ->update($updated_userExperience);

        if ($update_status) {
            return response()->json(compact('userExperience'), 201);
        } else {
            return response()->json(['error' => 'something went wrong'], 400);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $user_experience_guid
     * @return \Illuminate\Http\Response
     */
    public function destroy($user_experience_guid)
    {
        $userExperience = UserExperience::where('user_experience_guid', $user_experience_guid)->first();
        if ($userExperience['user_id'] !== \Auth::user()['id']) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }
        $userExperience->delete();
        return response()->json(['success' => 'Experience entry deleted'], 200);
    }
}
