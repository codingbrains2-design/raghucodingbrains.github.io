<?php

namespace App\Http\Controllers;

use App\UserDetail;
use App\Competency;
use App\Industry;
use App\Location;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Faker;

class UserDetailController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = \Auth::user()
        ->with(
            'locations',
            'competencies',
            'industries',
            'userDetail',
            'userExperience',
            'userEducation'
        )
        ->get();
        return response()->json(compact('user'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $internals = Faker\Factory::create('en_US');
        $user = \Auth::user();

        $userDetail = UserDetail::updateOrCreate(
            ['user_id' => $user->id],
            [
                'user_details_guid' => $internals->uuid,
                'headline' => $request['headline'],
                'weekly_digest_email' => $request['weekly_digest_email'],
                'suggested_job_email' => $request['suggested_job_email'],
                'email_offers' => $request['email_offers'],
                'available' => $request['available'],
                'day_rate' => $request['day_rate'],
                'is_searchable' => $request['is_searchable']
            ]
        );

        $user->competencies()->detach();
        $user->industries()->detach();
        $user->locations()->detach();
        $this->attachUserDetails($user, $request);
        return response()->json(compact('userDetail'), 201);
    }

    public function show($user_guid)
    {
        $user = \Auth::user()->with(
            'locations',
            'competencies',
            'industries',
            'userDetail',
            'userExperience',
            'userEducation'
        )
        ->first();
        return response()->json(compact('user'), 200);
    }

    private function attachUserDetails($user, $request)
    {
        if ($request['locations']) {
            foreach ($request['locations'] as $location_guid) {
                $location = Location::where('location_guid', $location_guid)->first();
                $user->locations()->attach($location);
            }
        }

        if ($request['industries']) {
            foreach ($request['industries'] as $industry_guid) {
                $industry = Industry::where('industry_guid', $industry_guid)->first();
                if (!$industry) {
                    $industry = IndustryController::store(['name' => $industry_guid]);
                }
                $user->industries()->attach($industry);
            }
        }

        if ($request['competencies']) {
            foreach ($request['competencies'] as $competency_guid) {
                $competency = Competency::where('competency_guid', $competency_guid)->first();
                if (!$competency) {
                    $competency = CompetencyController::store(['name' => $competency_guid]);
                }
                $user->competencies()->attach($competency);
            }
        }
    }
}
