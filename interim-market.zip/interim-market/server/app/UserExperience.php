<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UserExperience extends Model
{

    protected $table = 'user_experience';

    protected $fillable = ['user_experience_guid' , 'user_id', 'job_position', 'company_name', 'job_status',
        'achievements', 'start_date', 'end_date'];

    protected $hidden = ['id', 'user_id'];
}
