<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UserEducation extends Model
{

    protected $table = 'user_education';

    protected $fillable = ['user_education_guid', 'user_id', 'school', 'degree', 'grades',
        'start_date', 'end_date'];

    protected $hidden = ['id', 'user_id', 'updated_at', 'created_at'];
}
