<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserDetail extends Model
{
    protected $table = 'users_details';

    protected $fillable = ['user_details_guid', 'user_id', 'cv_name', 'headline', 'user_avatar',
        'position_title', 'linkedin_profile_url', 'youtube_profile_url', 'github_profile_url',
        'mobile_number', 'alternate_mobile_number', 'hobbies', 'weekly_digest_email', 'suggested_job_email',
        'email_offers', 'available', 'day_rate', 'is_searchable'];

    protected $hidden = ['id', 'user_id'];

    protected $dates = ['created_at', 'updated_at'];
}
