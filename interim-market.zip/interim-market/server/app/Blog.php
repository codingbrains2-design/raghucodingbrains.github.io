<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Blog extends Model
{

    protected $table = 'blogs';

    protected $fillable = ['blog_guid','user_id', 'title', 'blog', 'slug', 'twitter_title',
        'twitter_description', 'facebook_title', 'facebook_description', 'views', 'is_active',
        'published_at', 'created_at'];

    protected $hidden = ['id', 'user_id', 'slug', 'is_active'];

    public function user()
    {
        return $this->belongsTo('App\User');
    }
}
