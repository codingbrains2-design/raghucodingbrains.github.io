<?php

namespace App\Policies;

use App\Company;
use App\User;
use App\Application;
use Illuminate\Auth\Access\HandlesAuthorization;

class ApplicationPolicy
{
    use HandlesAuthorization;

    public function update(User $user, Application $application)
    {
        if ($application['applicant_type'] === 'App\User') {
            if ($application['applicant_id'] === $user['id']) {
                return true;
            }
        } else {
            $company = Company::find($application['applicant_id']);
            $role = Helper::getRole($user, $company);
            if ($role !== 'member') {
                return true;
            }
        }
        $company = $application->job()->employer()->first();
        $role = Helper::getRole($user, $company);
        return $role !== 'member';
    }

    public function delete(User $user, Application $application)
    {
        if ($application['applicant_type'] === 'App\User') {
            return $application['applicant_id'] === $user['id'];
        } else {
            $company = Company::find($application['applicant_id']);
            $role = Helper::getRole($user, $company);
            return $role !== 'member';
        }
    }

    public function updateEmployerApproval(User $user, Application $application)
    {
        $company = $application->job()->first()->employer->first();
        $role = Helper::getRole($user, $company);
        return $role !== 'member';
    }

    public function updateApplicantApproval(User $user, Application $application)
    {
        if ($application['applicant_type'] === 'App\User') {
            return $application['applicant_id'] === $user['id'];
        } else {
            $company = Company::find($application['applicant_id']);
            $role = Helper::getRole($user, $company);
            return $role !== 'member';
        }
    }
}
