<?php
/**
 * Created by IntelliJ IDEA.
 * User: Kiran
 * Date: 6/11/2017
 * Time: 3:44 PM
 */

namespace App\Policies;

class Helper
{
    public static function getRole($user, $company)
    {
        $company = $user->companies()->find($company['id']);
        return $company->pivot['role'];
    }
}
