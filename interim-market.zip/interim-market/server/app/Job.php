<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Job extends Model
{
    protected $table = 'im_jobs';

    protected $fillable = ['job_guid', 'job_heading', 'job_description', 'status', 'location_id',
        'employer_id', 'currency','salary_start', 'salary_end', 'created_by'];

    protected $hidden = ['id', 'location_id'];

    public function location()
    {
        return $this->belongsTo('App\Location');
    }

    public function creator()
    {
        return $this->belongsTo('App\User', 'created_by');
    }

    public function employer()
    {
        return $this->belongsTo('App\Company', 'employer_id');
    }

    public function contractUsers()
    {
        return $this->morphedByMany('App\User', 'contractor', 'contracts')
            ->withPivot(['start_date', 'end_date', 'currency', 'contract_rate','payment_frequency']);
    }

    public function contractCompanies()
    {
        return $this->morphedByMany('App\Company', 'contractor', 'contracts')
            ->withPivot(['start_date', 'end_date', 'currency', 'contract_rate','payment_frequency']);
    }

    public function companyApplications()
    {
        return $this->morphedByMany('App\Company', 'applicant', 'applications')
            ->withPivot(['proposed_start_date', 'proposed_end_date','employer_approval', 'applicant_approval',
                'currency', 'proposed_contract_rate', 'payment_frequency']);
    }

    public function userApplications()
    {
        return $this->morphedByMany('App\User', 'applicant', 'applications')
            ->withPivot(['proposed_start_date', 'proposed_end_date','employer_approval', 'applicant_approval',
                'currency', 'proposed_contract_rate', 'payment_frequency']);
    }

    public function competencies()
    {
        return $this->morphToMany('App\Competency', 'competency_mappable', 'competency_maps');
    }
}
