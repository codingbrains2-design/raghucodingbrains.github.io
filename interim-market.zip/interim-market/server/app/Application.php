<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Application extends Model
{
    use SoftDeletes;

    protected $table = 'applications';

    protected $fillable = ['application_guid', 'applicant_id', 'applicant_type', 'job_id', 'proposed_start_date',
        'proposed_end_date', 'employer_approval', 'applicant_approval', 'currency', 'proposed_contract_rate',
        'payment_frequency'];

    protected $hidden = ['id', 'applicant_id', 'applicant_type', 'job_id'];

    public function job()
    {
        return $this->belongsTo('App\Job');
    }
}
