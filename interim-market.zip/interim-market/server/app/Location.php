<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Location extends Model
{

    protected $table = 'locations';

    protected $fillable = ['location_guid', 'place_id', 'location_name'];

    protected $hidden = ['id', 'place_id', 'created_at', 'updated_at'];

    protected $dates = ['created_at', 'updated_at'];

    public function jobs()
    {
        return $this->hasMany('App\Job');
    }

    public function companies()
    {
        return $this->belongsToMany('App\Company');
    }

    public function users()
    {
        return $this->belongsToMany('App\User');
    }
}
