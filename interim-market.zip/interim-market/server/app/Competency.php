<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Competency extends Model
{
    protected $table = 'competencies';

    protected $fillable = ['competency_guid', 'name'];

    protected $hidden = ['id', 'pivot'];
}
