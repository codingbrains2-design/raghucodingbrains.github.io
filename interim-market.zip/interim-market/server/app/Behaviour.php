<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Behaviour extends Model
{

    protected $table = 'behaviours';

    protected $fillable = ['behaviour_guid', 'name'];

    protected $hidden = ['id'];

    public function companies()
    {
        return $this->morphedByMany('App\Company', 'behaviour_mappable');
    }

    public function users()
    {
        return $this->morphedByMany('App\user', 'behaviour_mappable');
    }
}
