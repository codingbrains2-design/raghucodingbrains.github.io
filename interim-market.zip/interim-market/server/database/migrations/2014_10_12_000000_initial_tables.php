<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class InitialTables extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->string('user_guid', 36);
            $table->string('linkedin_id')->nullable();
            $table->string('email')->unique();
            $table->string('password', 60)->nullable();
            $table->string('first_name', 30)->nullable();
            $table->string('last_name', 30)->nullable();
            $table->boolean('im_superuser')->default(false);
            $table->boolean('im_staff')->default(false);
            $table->string('hash', 32)->nullable();
            $table->boolean('is_verified')->default(false);
            $table->boolean('is_active')->default(true);
            $table->boolean('is_blocked')->default(false);
            $table->integer('default_company')->unsigned()->nullable();
            $table->boolean('is_searchable')->default(true);
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::create('users_details', function (Blueprint $table) {
            $table->increments('id');
            $table->string('user_details_guid', 36);
            $table->integer('user_id')->unsigned();
            $table->string('cv_name', 50)->nullable();
            $table->string('headline', 256);
            $table->text('user_avatar')->nullable();
            $table->string('position_title', 50)->nullable();
            $table->string('linkedin_profile_url', 128)->nullable();
            $table->string('youtube_profile_url', 128)->nullable();
            $table->string('github_profile_url', 128)->nullable();
            $table->string('mobile_number', 15)->nullable();
            $table->string('alternate_mobile_number', 15)->nullable();
            $table->string('hobbies', 256)->nullable();
            $table->boolean('weekly_digest_email')->default(true);
            $table->boolean('suggested_job_email')->default(true);
            $table->boolean('email_offers')->default(true);
            $table->enum('available', [
                'Available Immediately', 
                'Available in 1-3 months', 
                'Available in 4-6 months', 
                'Not Actively Looking'
            ]);
            $table->enum('day_rate', [
                '£200 - £400', 
                '£400 - £700', 
                '£700 - £1000', 
                '£1000+'
            ])->nullable();
            $table->boolean('is_searchable')->default(true);
            $table->timestamps();
        });

        Schema::create('user_education', function (Blueprint $table) {
            $table->increments('id');
            $table->string('user_education_guid', 36);
            $table->integer('user_id')->unsigned();
            $table->string('school', 150);
            $table->string('degree', 100);
            $table->string('grades', 100);
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->timestamps();
        });

        Schema::create('user_experience', function (Blueprint $table) {
            $table->increments('id');
            $table->string('user_experience_guid', 36);
            $table->integer('user_id')->unsigned();
            $table->string('job_position', 150);
            $table->string('company_name', 150);
            $table->boolean('job_status')->default(false);
            $table->text('achievements')->nullable();
            $table->date('start_date');
            $table->date('end_date')->nullable();
            $table->timestamps();
        });

        Schema::create('blogs', function (Blueprint $table) {
            $table->increments('id');
            $table->string('blog_guid', 36);
            $table->integer('user_id')->unsigned();
            $table->string('title', 150);
            $table->text('blog');
            $table->string('slug', 150);
            $table->string('twitter_title', 150)->nullable();
            $table->text('twitter_description')->nullable();
            $table->string('facebook_title', 150)->nullable();
            $table->text('facebook_description')->nullable();
            $table->integer('views')->unsigned()->default(0);
            $table->boolean('is_active')->default(false);
            $table->datetime('published_at')->nullable();
            $table->timestamps();
        });

        Schema::create('companies', function (Blueprint $table) {
            $table->increments('id');
            $table->string('company_guid', 36);
            $table->integer('created_by')->unsigned();
            $table->string('company_code')->nullable();
            $table->string('company_name', 100);
            $table->text('company_website');
            $table->text('company_description');
            $table->string('contact', 20);
            $table->boolean('is_employer');
            $table->boolean('is_searchable');
            $table->enum('available', [
                'Available Immediately', 
                'Available in 1-3 months', 
                'Available in 4-6 months', 
                'Not Actively Looking'
                ]);
            $table->softDeletes();
            $table->timestamps();
        });

        Schema::create('company_user', function (Blueprint $table) {
            $table->integer('user_id')->unsigned();
            $table->integer('company_id')->unsigned();
            $table->string('employee_id')->nullable();
            $table->string('designation')->nullable();
            $table->enum('role', ['superuser', 'admin', 'member'])->nullable();
            $table->enum('invitation_status', ['pending', 'accepted']);
            $table->primary(['user_id', 'company_id']);
            $table->unique(['company_id', 'employee_id']);
            $table->timestamps();
        });

        Schema::create('applications', function (Blueprint $table) {
            $table->increments('id')->unsigned();
            $table->string('application_guid', 36);
            $table->integer('applicant_id')->unsigned();
            $table->string('applicant_type', 100);
            $table->integer('job_id')->unsigned();
            $table->date('proposed_start_date')->nullable();
            $table->date('proposed_end_date')->nullable();
            $table->enum('employer_approval', ['pending', 'approved', 'denied']);
            $table->enum('applicant_approval', ['pending', 'approved', 'denied']);
            $table->string('currency', 20);
            $table->integer('proposed_contract_rate')->unsigned();
            $table->enum('payment_frequency', ['weekly', 'monthly', 'yearly']);
            $table->softDeletes();
            $table->timestamps();
        });

        Schema::create('contracts', function (Blueprint $table) {
            $table->increments('id')->unsigned();
            $table->string('contract_guid', 36);
            $table->integer('contractor_id')->unsigned();
            $table->string('contractor_type', 100);
            $table->integer('job_id')->unsigned();
            $table->date('start_date');
            $table->date('end_date');
            $table->string('currency', 20);
            $table->integer('contract_rate')->unsigned();
            $table->enum('payment_frequency', ['weekly', 'monthly', 'yearly']);
            $table->softDeletes();
            $table->timestamps();
        });

        Schema::create('industries', function (Blueprint $table) {
            $table->increments('id')->unsigned();
            $table->string('industry_guid', 36);
            $table->string('name', 100);
            $table->boolean('is_approved')->default(false);
        });

        Schema::create('industry_maps', function (Blueprint $table) {
            $table->integer('industry_id')->unsigned();
            $table->integer('industry_mappable_id');
            $table->string('industry_mappable_type', 100);
        });

        Schema::create('plans', function (Blueprint $table) {
            $table->increments('id');
            $table->string('plan_guid', 36);
            $table->string('name', 100);
        });

        Schema::create('plan_maps', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('plan_mappable_id')->unsigned();
            $table->string('plan_mappable_type', 100);
            $table->date('start_date');
            $table->date('end_date');
        });

        Schema::create('locations', function (Blueprint $table) {
            $table->increments('id');
            $table->string('location_guid', 36);
            $table->text('place_id')->nullable();
            $table->string('location_name');
            $table->timestamps();
        });

        Schema::create('location_maps', function (Blueprint $table) {
            $table->integer('location_id')->unsigned();
            $table->integer('location_mappable_id');
            $table->string('location_mappable_type', 100);
        });

        Schema::create('competencies', function (Blueprint $table) {
            $table->increments('id');
            $table->string('competency_guid', 36);
            $table->string('name');
            $table->boolean('is_approved')->default(false);
        });

        Schema::create('competency_maps', function (Blueprint $table) {
            $table->integer('competency_id')->unsigned();
            $table->integer('competency_mappable_id');
            $table->string('competency_mappable_type', 100);
        });

        Schema::create('behaviours', function (Blueprint $table) {
            $table->increments('id');
            $table->string('behaviour_guid', 36);
            $table->string('name');
            $table->boolean('is_approved')->default(false);
        });

        Schema::create('behaviours_maps', function (Blueprint $table) {
            $table->integer('behaviour_id');
            $table->integer('behaviour_mappable_id');
            $table->string('behaviour_mappable_type', 100);
        });

        Schema::create('im_jobs', function (Blueprint $table) {
            $table->increments('id');
            $table->string('job_guid', 36);
            $table->string('job_heading' ,500);
            $table->text('job_description');
            $table->enum('status', ['open', 'closed']);
            $table->integer('location_id')->unsigned();
            $table->integer('created_by')->unsigned();
            $table->integer('employer_id')->unsigned();
            $table->string('currency', 20);
            $table->integer('salary_start')->nullable();
            $table->integer('salary_end')->nullable();
            $table->date('validity_start_date')->nullable();
            $table->date('validity_end_date')->nullable();
            $table->timestamps();
        });

        Schema::table('im_jobs', function (Blueprint $table) {
            $table->foreign('created_by')->references('id')->on('users');
            $table->foreign('employer_id')->references('id')->on('companies');
            $table->foreign('location_id')->references('id')->on('locations');
        });

        Schema::table('companies', function (Blueprint $table) {
            $table->foreign('created_by')->references('id')->on('users');
        });

         Schema::table('users_details', function (Blueprint $table) {
            $table->foreign('user_id')->references('id')->on('users');
        });

        Schema::table('user_education', function (Blueprint $table) {
            $table->foreign('user_id')->references('id')->on('users');
        });

        Schema::table('user_experience', function (Blueprint $table) {
            $table->foreign('user_id')->references('id')->on('users');
        });

        Schema::table('blogs', function (Blueprint $table) {
            $table->foreign('user_id')->references('id')->on('users');
        });

        Schema::table('industry_maps', function (Blueprint $table) {
            $table->foreign('industry_id')->references('id')->on('industries');
        });

        Schema::table('location_maps', function (Blueprint $table) {
            $table->foreign('location_id')->references('id')->on('locations');
        });

        Schema::table('competency_maps', function (Blueprint $table) {
            $table->foreign('competency_id')->references('id')->on('competencies');
        });

        Schema::table('company_user', function (Blueprint $table) {
            $table->foreign('user_id')->references('id')->on('users');
            $table->foreign('company_id')->references('id')->on('companies');
        });

        Schema::table('contracts', function (Blueprint $table) {
            $table->foreign('job_id')->references('id')->on('im_jobs');
        });

        Schema::table('applications', function (Blueprint $table) {
            $table->foreign('job_id')->references('id')->on('im_jobs');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->dropForeign(['created_by']);
        });

        Schema::table('users_details', function (Blueprint $table) {
            $table->dropForeign(['user_id']);
        });

        Schema::table('user_education', function (Blueprint $table) {
            $table->dropForeign(['user_id']);
        });

        Schema::table('user_experience', function (Blueprint $table) {
            $table->dropForeign(['user_id']);
        });

        Schema::table('blogs', function (Blueprint $table) {
            $table->dropForeign(['user_id']);
        });

        Schema::table('industry_maps', function (Blueprint $table) {
            $table->dropForeign(['industry_id']);
        });

        Schema::table('location_maps', function (Blueprint $table) {
            $table->dropForeign(['location_id']);
        });

        Schema::table('competency_maps', function (Blueprint $table) {
            $table->dropForeign(['competency_id']);
        });

        Schema::table('im_jobs', function (Blueprint $table) {
            $table->dropForeign(['created_by']);
            $table->dropForeign(['employer_id']);
            $table->dropForeign(['location_id']);
        });

        Schema::table('company_user', function (Blueprint $table) {
            $table->dropForeign(['user_id']);
            $table->dropForeign(['company_id']);
        });

        Schema::table('contracts', function (Blueprint $table) {
            $table->dropForeign(['job_id']);
        });

        Schema::table('applications', function (Blueprint $table) {
            $table->dropForeign(['job_id']);
        });

        Schema::dropIfExists('contracts');
        Schema::dropIfExists('applications');
        Schema::dropIfExists('companies');
        Schema::dropIfExists('company_user');
        Schema::dropIfExists('locations');
        Schema::dropIfExists('location_maps');
        Schema::dropIfExists('competencies');
        Schema::dropIfExists('competency_maps');
        Schema::dropIfExists('users');
        Schema::dropIfExists('im_jobs');
        Schema::dropIfExists('users_details');
        Schema::dropIfExists('user_education');
        Schema::dropIfExists('user_experience');
        Schema::dropIfExists('blogs');
        Schema::dropIfExists('plans');
        Schema::dropIfExists('plan_maps');    
        Schema::dropIfExists('industries');
        Schema::dropIfExists('industry_maps');
        Schema::dropIfExists('behaviours');
        Schema::dropIfExists('behaviours_maps');
    }
}
