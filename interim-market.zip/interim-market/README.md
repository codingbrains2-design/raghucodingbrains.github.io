# Interimarket
Interimarket Application

[![Build Status](http://im-jenkins.interimarket.com:8080/buildStatus/icon?job=ci-interimarket)](http://im-jenkins.interimarket.com:8080/job/ci-interimarket)
