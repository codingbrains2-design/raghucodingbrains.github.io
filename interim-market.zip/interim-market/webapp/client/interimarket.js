import 'babel-polyfill';
import React from 'react';
import ReactDOM from 'react-dom';
import injectTapEventPlugin from 'react-tap-event-plugin';
import Main from './components/Main';
import {Router, Route, hashHistory, Redirect} from 'react-router';
import configureStore from './store/configureStore';
import {Provider} from 'react-redux';
import rootSaga from './sagas/index';
import {syncHistoryWithStore} from 'react-router-redux';
import 'Assets/css/root.css';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import EmployersLanding from './components/landing/EmployersLanding';
import ContractorsLanding from './components/landing/ContractorsLanding';
import TermsOfService from './components/landing/TermsOfService';
import PrivacyPolicy from './components/landing/PrivacyPolicy';
import ContactUs from './components/landing/ContactUs';
import AuthContainer from './components/auth/AuthContainer';
import Error from './components/Error';

injectTapEventPlugin();

const store = configureStore();
const history = syncHistoryWithStore(hashHistory, store);
store.runSaga(rootSaga);

const checkType = (route) => {
  scrollToTop();
  const types = ['employers', 'contractors'];
  if (!types.includes(route.params.type)) {
    hashHistory.replace('error');
  }
};

const scrollToTop = () => {
  window.scrollTo(0, 0)
};

const router = (
  <Provider store={store}>
    <Router history={history}>
      <Redirect from="/" to="/employers"/>
      <Route path='/' component={Main}>
        <Route path='/employers' onEnter={scrollToTop} component={EmployersLanding}/>
        <Route path='/contractors' onEnter={scrollToTop} component={ContractorsLanding}/>
        <Route path='/:type/login' onEnter={checkType} component={AuthContainer}/>
        <Route path='/terms-of-service' onEnter={scrollToTop} component={TermsOfService}/>
        <Route path='/privacy-policy' onEnter={scrollToTop} component={PrivacyPolicy}/>
        <Route path='/contact-us' onEnter={scrollToTop} component={ContactUs}/>
        <Route path='*' component={Error}/>
      </Route>
    </Router>
  </Provider>
);

ReactDOM.render(
  router,
  document.getElementById('root')
);
