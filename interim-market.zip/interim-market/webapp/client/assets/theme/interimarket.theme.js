import getMuiTheme from 'material-ui/styles/getMuiTheme';
import {deepOrangeA200, grey500} from 'material-ui/styles/colors';

export const overlayColor = deepOrangeA200;
export const brandColor = '#873260';
export const mainColor = '#FAFAFB';

const muiTheme = getMuiTheme({
  palette: {
    primary1Color: overlayColor,
    secondaryColor: brandColor,
    accent1Color: deepOrangeA200,
  },
  appBar: {
    height: 65,
    textColor: brandColor,
    color: mainColor
  },
  tabs: {
    textColor: grey500,
    selectedTextColor: brandColor,
    backgroundColor: 'none'
  }
});

export default muiTheme;
