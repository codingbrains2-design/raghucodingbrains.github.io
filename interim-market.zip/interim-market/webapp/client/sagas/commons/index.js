import {takeLatest} from 'redux-saga';
import {put, call, fork} from 'redux-saga/effects';
import {SUBMIT_CONTACT_US, toggleSnackbar} from 'Actions/global';
import {HttpHelper} from '../utils/apis';

function *contactUs(params) {
  let formData = new FormData();
  formData.append('name', params.data.name);
  formData.append('email', params.data.email);
  formData.append('query_type', params.data.query_type);
  formData.append('description', params.data.description);
  // formData.append('contact_us_attachments', params.data.contact_us_attachments[0]);

  const response = yield call(HttpHelper, 'contact_us', 'POST', formData, null);
  if (response.status === 201) {
    yield put(toggleSnackbar('Thank you for contacting us. We will get back to you as soon as possible.'));
  }
}

/*
 Watchers
 */

function *watchContactUs() {
  yield* takeLatest(SUBMIT_CONTACT_US, contactUs)
}

export default function *commonSaga() {
  yield [
    fork(watchContactUs)
  ]
}
