/*
  Selectors to be used in redux saga
*/