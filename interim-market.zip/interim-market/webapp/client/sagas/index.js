/*
  Import all sagas and fork it in yield array
*/

import {fork} from 'redux-saga/effects';
import commonSaga from './commons/index';

export default function *rootSaga() {
  yield [
    fork(commonSaga),
  ]
}
