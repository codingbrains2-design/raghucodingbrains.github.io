export const TOGGLE_SNACKBAR = 'TOGGLE_SNACKBAR';
export const SUBMIT_CONTACT_US = 'SUBMIT_CONTACT_US';

export function toggleSnackbar(message = '') {
  return {
    type: TOGGLE_SNACKBAR,
    message
  }
}

export function submitContactUs(data) {
  return {
    type: SUBMIT_CONTACT_US,
    data
  }
}
