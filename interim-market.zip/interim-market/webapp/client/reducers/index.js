import {combineReducers} from 'redux';
import {routerReducer} from 'react-router-redux';
import snackbar from './snackbarReducer';

const rootReducer = combineReducers({
  snackbar,
  routing: routerReducer
});

export default rootReducer;
