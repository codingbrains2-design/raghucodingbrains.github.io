export default function initLinkedinApi(cb) {
  let br = document.createElement('br');
  let script = document.createElement('script');
  script.src = 'https://platform.linkedin.com/in.js';
  script.onload = cb;
  script.type = 'text/javascript';

  let config = document.createTextNode(`
    api_key: ${process.env.LINKEDIN_API_KEY}
    onLoad: onLinkedInLoad
    authorize: ${true}
  `);

  script.appendChild(config);

  // let s = document.getElementsByTagName('script')[0];
  // s.parentNode.insertBefore(script, s);
  document.body.appendChild(script);
};
