import React from 'react'
import {hashHistory} from 'react-router';
import {AppBar, RaisedButton, Tabs, Tab} from 'material-ui';
import {Row, Col} from 'react-flexbox-grid';
import {Link, scroller} from 'react-scroll'

class Navbar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedTab: -1
    }
  }

  get styles() {
    return {
      logo: {
        margin: '14px 10px 0 -8px'
      }
    }
  };

  componentDidMount() {
    const _this = this;
    $(window).bind('scroll.navbarScrollHandler', function () {
      let scroll = $(window).scrollTop();
      if (!scroll) {
        _this.setState({ selectedTab: -1 })
      }
    });
  }

  onTypeChange(current_path) {
    const { parentProps } = this.props;
    this.setState({ selectedTab: -1 });
    if (current_path === '/employers' || parentProps.params.type === 'employers') {
      hashHistory.push('/contractors');
      return;
    }
    hashHistory.push('/employers')
  };

  renderNavigationTabs() {
    const { parentProps } = this.props;
    const typeButtonLabel =
      parentProps.location.pathname === '/employers' || parentProps.params.type === 'employers' ?
        'Use as a Contractor' : 'Use as an Employer';

    if (parentProps.location.pathname === '/employers' ||
      parentProps.location.pathname === '/contractors') {

      return (
        <Row className="right-nav-container">
          <Col xs={3} style={{ textAlign: 'right', paddingRight: 15 }}>
            <RaisedButton
              buttonStyle={{borderRadius: 18, width: 180, height: 34, lineHeight: '34px'}}
              overlayStyle={{borderRadius: 18, height: 36}}
              style={{borderRadius: 18, boxShadow: 'none'}}
              label={typeButtonLabel}
              labelStyle={{ fontSize: 12, fontWeight: 400 }}
              secondary={true}
              onClick={() => this.onTypeChange(parentProps.location.pathname)}
            />
          </Col>
          {this.renderTabs()}
        </Row>
      )
    }
    else {
      return (
        <Row className="right-nav-container">
          <Col xs={3} style={{ textAlign: 'right', paddingRight: 15 }}>
            <RaisedButton
              buttonStyle={{ borderRadius: 18, width: 160, height: 32, lineHeight: '32px' }}
              overlayStyle={{ borderRadius: 18 }}
              style={{ borderRadius: 18, boxShadow: 'none' }}
              label="Home"
              labelStyle={{ fontSize: 12, fontWeight: 400 }}
              secondary={true}
              onClick={() => hashHistory.push('/')}
            />
          </Col>
        </Row>
      )
    }
  }

  renderTabs() {
    return (
      <Col xs={9}>
        <Tabs value={this.state.selectedTab}>
          <Tab
            className="tab"
            label="How it works?"
            value="how_it_works"
            containerElement={
              <Link
                to='how_it_works'
                spy={true}
                smooth="easeInOutQuint"
                offset={-60}
                duration={1000}
                onSetActive={() => this.setState({ selectedTab: 'how_it_works' })}
              />
            }
          />
          <Tab
            className="tab"
            label="About Us"
            value="about_us"
            containerElement={
              <Link
                to='about_us'
                spy={true}
                smooth="easeInOutQuint"
                offset={-60}
                duration={1000}
                onSetActive={() => this.setState({ selectedTab: 'about_us' })}
              />
            }
          />
          <Tab
            className="tab"
            label="Blogs"
            value="blogs"
            containerElement={
              <Link
                to='blogs'
                spy={true}
                smooth="easeInOutQuint"
                offset={-75}
                duration={1000}
                onSetActive={() => this.setState({ selectedTab: 'blogs' })}
              />
            }
          />
        </Tabs>
      </Col>
    );
  }

  render() {
    return (
      <div>
        <AppBar
          title="InteriMarket"
          titleStyle={{ flex: '0.4 0 0%', lineHeight: '70px' }}
          onTitleTouchTap={() => hashHistory.push('/')}
          className="navbar"
          iconStyleLeft={this.styles.logo}
          iconElementLeft={<img style={{ width: 50, cursor: 'pointer' }} src={require('Assets/images/logos/im.png')} />}
          onLeftIconButtonTouchTap={() => hashHistory.push('/')}
          iconStyleRight={{ marginTop: 0, flex: '0.58 0 0%' }}
          iconElementRight={this.renderNavigationTabs()}
        />
        <div className="navbar-highlight" />
      </div>
    );
  }
}

export default Navbar;
