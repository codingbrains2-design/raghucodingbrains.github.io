import React, {Component} from 'react';
import {Card, CardActions, CardText} from 'material-ui/Card';
import {RaisedButton, Avatar, Divider, FontIcon} from 'material-ui';
import {FormsyText} from 'formsy-material-ui/lib';
import {overlayColor, brandColor} from 'Assets/theme/interimarket.theme';
import {Col, Grid, Row} from 'react-flexbox-grid';
import SocialButtons from '../landing/SocialButtons';
import Footer from '../landing/Footer';

class AuthContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      canSubmit: false,
      formValid: false
    }
  }

  get styles() {
    return {
      formAvatar: {
        position: 'absolute',
        top: '-68px',
        marginLeft: 'auto',
        marginRight: 'auto',
        left: 0,
        right: 0
      },
      avatarStyle: {
        backgroundColor: 'transparent',
        borderStyle: 'solid',
        borderWidth: 'thin',
        borderColor: brandColor
      },
      linkedinButton: {
        float: 'left',
        top: 5,
        paddingRight: 12,
        borderRight: '1px solid #F5F5F5'
      }
    }
  }

  setFormValidity(enabled) {
    this.setState({canSubmit: enabled, formValid: enabled});
  }

  render() {
    return (
      <div>
        <div className="main-content">
          <div style={{margin: '11% 0 10%'}}>
            <Grid>
              <div className="wrap">
                <Col xs={12}>
                  <Row center="xs">
                    <Col xs={8} md={6}>
                      <Card style={{position: 'relative'}}>
                        <Formsy.Form
                          ref="form"
                          onValid={() => this.setFormValidity(true)}
                          onInvalid={() => this.setFormValidity(false)}
                        >
                          <CardText style={this.styles.formAvatar}>
                            <Avatar
                              src={require('Assets/images/avatar.png')}
                              size={100}
                              style={this.styles.avatarStyle}
                            />
                          </CardText>
                          <CardText style={{paddingTop: 55}}>
                            <Col xs={12}>
                              <FormsyText
                                style={{marginTop: 12}}
                                hintText="Email ID"
                                name="email"
                                fullWidth={true}
                                validations="isEmail"
                                validationError="Not a valid email id"
                                errorStyle={{float: 'left'}}
                                autoComplete="off"
                                required/>
                              <FormsyText
                                style={{marginTop: 12}}
                                type="password"
                                hintText="Password"
                                name="password"
                                fullWidth={true}
                                errorStyle={{float: 'left'}}
                                autoComplete="off"
                                required/>
                            </Col>
                          </CardText>
                          <CardActions style={{padding: '0 22px 30px'}}>
                            <RaisedButton
                              label="Login"
                              type="Login"
                              labelStyle={{fontSize: 11}}
                              secondary={true}
                              fullWidth={true}
                              disabled={!this.state.canSubmit}
                            />
                            <Row center="xs">
                              <Col xs={5}>
                                <CardText style={{paddingTop: 25}}>
                                  <Divider/>
                                </CardText>
                              </Col>
                              <Col xs={2}>
                                <CardText>or</CardText>
                              </Col>
                              <Col xs={5}>
                                <CardText style={{paddingTop: 25}}>
                                  <Divider/>
                                </CardText>
                              </Col>
                            </Row>
                            <RaisedButton
                              buttonStyle={{backgroundColor: '#0077B5'}}
                              label="Register with LinkedIn"
                              labelStyle={{fontSize: 11, marginLeft: '-16px'}}
                              icon={
                                <FontIcon
                                  style={this.styles.linkedinButton}
                                  className="fa fa-linkedin"
                                />
                              }
                              onClick={() => IN.User.authorize(null, {scope: ['r_basicprofile', 'r_emailaddress']})}
                              secondary={true}
                              fullWidth={true}
                            />
                          </CardActions>
                        </Formsy.Form>
                      </Card>
                    </Col>
                  </Row>
                </Col>
              </div>
            </Grid>
          </div>
        </div>
        <Footer parentProps={this.props}/>
        <SocialButtons/>
      </div>
    )
  }
}

export default AuthContainer;
