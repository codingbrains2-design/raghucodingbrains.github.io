import React from 'react';
import {} from 'material-ui';
import {Col, Row} from 'react-flexbox-grid';
import {brandColor} from 'Assets/theme/interimarket.theme';
import TeamMember from './TeamMember';

class Advisors extends React.Component {
  constructor(props) {
    super(props)
  }

  render() {
    return (
      <div style={{paddingBottom: 35}}>
        <Row center="xs">
          <h2 style={{marginTop: 35, color: '#FF851B'}}>Meet our Advisors</h2>
        </Row>
        <Row className="center-align" style={{margin: '40px 0'}}>
          <Col xs={6} md={4} lg={3}>
            <TeamMember name="Simon Berry" avatar={require('Assets/images/about/sb.jpg')} alternate={true} noRole={true}/>
          </Col>
          <Col xs={6} md={4} lg={3}>
            <TeamMember name="Keith Robson" avatar={require('Assets/images/about/kr.jpg')} alternate={true} noRole={true}/>
          </Col>
          <Col xs={6} md={4} lg={3}>
            <TeamMember name="Melanie Steel" avatar={require('Assets/images/about/ms.jpg')} alternate={true} noRole={true}/>
          </Col>
          <Col xs={6} md={4} lg={3}>
            <TeamMember name="Rahul Chakkara" avatar={require('Assets/images/about/rc.jpg')} alternate={true} noRole={true}/>
          </Col>
        </Row>
      </div>
    )
  }
}

export default Advisors;
