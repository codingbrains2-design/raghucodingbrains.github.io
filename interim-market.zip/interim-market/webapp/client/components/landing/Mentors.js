import React from 'react';
import {} from 'material-ui';
import {Col, Row} from 'react-flexbox-grid';
import {brandColor} from 'Assets/theme/interimarket.theme';
import TeamMember from './TeamMember';

class Mentors extends React.Component {
  constructor(props) {
    super(props)
  }

  render() {
    return (
      <div style={{paddingBottom: 35}}>
        <Row center="xs">
          <h2 style={{marginTop: 35}}>Meet our Mentors</h2>
        </Row>
        <Row className="center-align" style={{margin: '40px 0'}}>
          <Col xs={12}>
            <Row center="xs">
              <Col xs={4}>
                <TeamMember name="Marco Botticelli" avatar={require('Assets/images/about/mb.jpg')} noRole={true}/>
              </Col>
            </Row>
          </Col>
        </Row>
      </div>
    )
  }
}

export default Mentors;
