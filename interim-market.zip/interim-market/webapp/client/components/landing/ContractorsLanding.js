import React from 'react';
import {hashHistory} from 'react-router';
import {Element, Link} from 'react-scroll';
import {FloatingActionButton, Paper, RaisedButton} from 'material-ui';
import {overlayColor, brandColor, mainColor} from 'Assets/theme/interimarket.theme';
import {Col, Grid, Row} from 'react-flexbox-grid';
import {NavigationArrowDownward} from 'material-ui/svg-icons/index';
import HowItWorks from './HowItWorks';
import SocialButtons from './SocialButtons';
import Footer from './Footer';
import AboutUs from './AboutUs';
import Advisors from './Advisors';
import Mentors from './Mentors';

class ContractorsLanding extends React.Component {
  constructor(props) {
    super(props)
  }

  get styles() {
    return {
      logo: {
        margin: '14px 10px 0 -8px'
      },
      header: {
        background: null,
        position: 'relative'
      },
      headerContainer: {
        backgroundColor: 'transparent',
        display: 'table-cell',
        verticalAlign: 'middle'
      },
      heading: {
        textTransform: 'uppercase',
        color: 'white',
        fontSize: '4vmin'
      },
      howItWorksContainer: {
        position: 'relative',
        borderRadius: 0,
        backgroundColor: '#85144B',
        color: '#FF851B',
        borderTop: '2px solid #FF851B'
      }
    }
  };

  componentDidMount() {
    $('.header').backstretch(require('Assets/images/contractors.jpg'));
    this.renderTaglines();
  }

  renderTaglines() {
    let _this = this;
    let tags = [
      'Search from <span style="color: #FF6E40">thousands of jobs</span> in one place',
      'Connect and collaborate with companies you <span style="color: #FF6E40">admire</span>',
      '<span style="color: #FF6E40">No agencies</span> or third parties',
      'Let companies head-hunt you through our <span style="color: #FF6E40">intelligent matching</span>'
    ];
    let count = 0;
    $(_this.refs.tags).animate({opacity: 0}, 750, function () {
      $(this).html(tags[count]).animate({opacity: 1}, 750)
    });
    setInterval(function () {
      count++;
      if (count >= tags.length) {
        count = 0
      }
      $(_this.refs.tags).animate({opacity: 0}, 750, function () {
        $(this).html(tags[count]).animate({opacity: 1}, 750)
      });
    }, 5800)
  }

  render() {
    return (
      <div>
        <div className="header">
          <div className="overlay">
            <div className="main-content">
              <div className="wrap">
                <Row center="xs" style={{height: '82vh', width: '100%', display: 'table'}}>
                  <Paper zDepth={0} style={this.styles.headerContainer}>
                    <h1 ref="tags" style={this.styles.heading}/>
                    <RaisedButton
                      style={{marginTop: 20}}
                      labelStyle={{fontWeight: 400}}
                      secondary={true}
                      onClick={() => hashHistory.push('/contractors/login')}
                      label="Sign In and get Started"
                    />
                  </Paper>
                </Row>
              </div>
            </div>
          </div>
        </div>
        <Paper zDepth={5} style={this.styles.howItWorksContainer}>
          <div className="wrap">
            <Col xs={12}>
              <Row center="xs" style={{height: 45}}>
                <div style={{position: 'relative', top: '-28px'}}>
                  <FloatingActionButton
                    backgroundColor={mainColor}
                    containerElement={
                      <Link
                        to='how_it_works'
                        spy={true}
                        smooth="easeInOutQuint"
                        offset={-75}
                        duration={1000}
                      />
                    }
                  >
                    <NavigationArrowDownward style={{color: overlayColor, fill: overlayColor}}/>
                  </FloatingActionButton>
                </div>
              </Row>
              <Element name='how_it_works'>
                <HowItWorks parentProps={this.props}/>
              </Element>
            </Col>
          </div>
        </Paper>
        <Paper zDepth={5} style={{position: 'relative', borderRadius: 0}}>
          <div className="wrap">
            <Col xs={12}>
              <Element name='about_us'>
                <AboutUs parentProps={this.props}/>
              </Element>
            </Col>
          </div>
        </Paper>
        <Paper zDepth={2} style={this.styles.howItWorksContainer}>
          <div className="wrap">
            <Col xs={12}>
              <Advisors parentProps={this.props}/>
            </Col>
          </div>
        </Paper>
        <Paper zDepth={5} style={{position: 'relative', borderRadius: 0, backgroundColor: '#F6F6F6'}}>
          <div className="wrap">
            <Col xs={12}>
              <Mentors parentProps={this.props}/>
            </Col>
          </div>
        </Paper>
        <Footer parentProps={this.props}/>
        <SocialButtons/>
      </div>
    )
  }
}

export default ContractorsLanding;
