import React from 'react';
import {Row, Col} from 'react-flexbox-grid';
import {overlayColor} from 'Assets/theme/interimarket.theme';
import {grey300} from 'material-ui/styles/colors';
import YoutubePlayer from 'react-youtube-player';

class HowItWorks extends React.Component {
  constructor(props) {
    super(props)
  }

  get styles() {
    return {
      heading: {
        fontWeight: 500,
        display: 'block',
        padding: '20px 0 2px'
      },
      description: {
        fontWeight: 300
      },
      videoLabel: {
        fontWeight: 400,
        fontSize: 30,
        textTransform: 'capitalize',
        display: 'table-cell',
        verticalAlign: 'middle',
        paddingLeft: 15,
        height: 'inherit'
      },
      videoLabelContainer: {
        display: 'table',
        height: '100%'
      },
      divider: {
        margin: '5px 65px 15px 65px',
        backgroundColor: grey300,
        height: 1,
        border: 'none'
      }
    }
  }

  renderForEmployers() {
    return (
      <Row className="center-align" style={{margin: '35px 0px'}}>
        <Col xs={3} className="hiw-containers">
          <img src={require('Assets/images/how_it_works/employers/rehire_o.png')} width={100}/>
          <label style={this.styles.heading}>Hire & re-hire</label>
          <p className="lead">
            Create job announcements and get matched, hire top interim talent through the marketplace or
            Re-Hire your past contractor talent quick and easy
          </p>
        </Col>
        <Col xs={3} className="hiw-containers">
          <img src={require('Assets/images/how_it_works/employers/hub_o.png')} width={100}/>
          <label style={this.styles.heading}>Employers Hub</label>
          <p className="lead">
            On board your current and new contractors on your personal cloud hub and see real-time activity directly
          </p>
        </Col>
        <Col xs={3} className="hiw-containers">
          <img src={require('Assets/images/how_it_works/employers/analytics_o.png')} width={100}
               style={{paddingTop: 8}}/>
          <label style={{...this.styles.heading, paddingTop: 27}}>Data Analytics</label>
          <p className="lead">
            Gain valuable insights that empower you to make informed decisions
          </p>
        </Col>
        <Col xs={3} className="hiw-containers">
          <img src={require('Assets/images/how_it_works/employers/exclusive_o.png')} width={100}
               style={{paddingTop: 2}}/>
          <label style={{...this.styles.heading, paddingTop: 27}}>Exclusive community, No agencies</label>
          <p className="lead">
            Follow and allow most relevant and talented community of interims and contractors to follow you back
          </p>
        </Col>
        <Col xsOffset={1} xs={10} style={{height: 500, marginTop: 50}}>
          <YoutubePlayer
            videoId='opipSWMKZ4M'
            playbackState='unstarted'
            configuration={{
              showinfo: 0,
              controls: 0
            }}
          />
        </Col>
      </Row>
    )
  }

  renderForContractors() {
    return (
      <Row className="center-align" style={{margin: '35px 0px'}}>
        <Col xs={3} className="hiw-containers">
          <img src={require('Assets/images/how_it_works/contractors/recruit.png')} width={100}/>
          <label style={this.styles.heading}>Get found direct</label>
          <p className="lead">
            Get directly headhunted by organisations, no agencies or third parties
          </p>
        </Col>
        <Col xs={3} className="hiw-containers">
          <img src={require('Assets/images/how_it_works/contractors/career.png')} width={100}/>
          <label style={this.styles.heading}>Build Portfolio</label>
          <p className="lead">
            Start building a real time portfolio with our profiling mechanism; it grows with your career. No more CVs
          </p>
        </Col>
        <Col xs={3} className="hiw-containers">
          <img src={require('Assets/images/how_it_works/contractors/noun.png')} width={100}/>
          <label style={this.styles.heading}>Pipeline Work, Fast</label>
          <p className="lead">
            Take control of your career and build a strong pipeline of thousands of assignments direct
          </p>
        </Col>
        <Col xs={3} className="hiw-containers">
          <img src={require('Assets/images/how_it_works/contractors/community.png')} width={100}/>
          <label style={this.styles.heading}>Exclusive Community</label>
          <p className="lead">
            Follow organisations and peers, become part of a great exclusive community and find all you need in the same
            place
          </p>
        </Col>
        <Col xsOffset={1} xs={10} style={{height: 500, marginTop: 50}}>
          <YoutubePlayer
            videoId='7vgp3qZCgBs'
            playbackState='unstarted'
            configuration={{
              showinfo: 0,
              controls: 0
            }}
          />
        </Col>
      </Row>
    )
  }

  renderHowItWorks() {
    const current_path = this.props.parentProps.location.pathname;
    if (current_path === '/employers') {
      return this.renderForEmployers();
    } else {
      return this.renderForContractors();
    }
  }

  render() {
    return (
      <div className="body" style={{padding: '20px 0px 20px'}}>
        <Row center="xs">
          <h2 style={{marginTop: 0}}>How it works?</h2>
        </Row>
        {this.renderHowItWorks()}
      </div>
    )
  }
}

export default HowItWorks;
