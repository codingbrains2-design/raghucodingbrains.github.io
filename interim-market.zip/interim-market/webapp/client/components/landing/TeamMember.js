import React, {Component} from 'react';
import {Avatar, Card, CardHeader, CardText} from 'material-ui';
import json from 'Assets/data/team.json';

class TeamMember extends Component {
  constructor(props) {
    super(props);
    this.state = {
      expanded: false
    }
  }

  handleToggle = () => {
    this.setState({expanded: !this.state.expanded});
  };

  render() {
    const data = json[this.props.name];
    const visibility = this.state.expanded ? 'block' : 'none';
    let color = this.props.alternate ? (this.state.expanded ? '#333333' : '#FF851B') : '#333333';
    const border = this.props.alternate ? (this.state.expanded ? '4px solid #FFF' : '4px solid #FF851B') : '4px solid #FFF';
    const marginTop = this.props.noRole ? '-90px' : '-110px';

    return (
      <div style={{marginTop: 20}}>
        <div>
          <Avatar
            onTouchTap={this.handleToggle}
            style={{border}}
            src={this.props.avatar}
            size={this.state.expanded ? 100 : 200}
          />
          <div className="about">
            <p className="name" onClick={this.handleToggle} style={{cursor: 'pointer', color}}>
              {this.props.name}
            </p>
            {data.role !== null ? <p className="designation">{data.role}</p> : <span/>}
          </div>
        </div>
        <Card expanded={this.state.expanded} style={{marginTop, display: visibility}}>
          <CardText style={{height: 100, padding: 0}}/>
          <CardText expandable={true}>
            <p style={{margin: 0, fontSize: 16, lineHeight: '22px', fontWeight: 300}}>
              {data.description}
            </p>
          </CardText>
        </Card>
      </div>
    )
  }
}

export default TeamMember;
