import React, {Component} from 'react';
import {FloatingActionButton, FontIcon} from 'material-ui';

class SocialButtons extends Component {
  constructor(props) {
    super(props)
  }

  get styles() {
    return {
      buttonContainer: {
        position: 'fixed',
        right: 15,
        top: '40%',
        marginTop: '-50px',
        zIndex: 1
      },
      button: {
        display: 'block',
        marginTop: 8
      }
    }
  }

  onButtonClick(type) {
    switch (type) {
      case 'facebook':
        window.open('https://www.facebook.com/InteriMarket', '_blank');
        return;
      case 'twitter':
        window.open('https://twitter.com/InteriMarket', '_blank');
        return;
      case 'youtube':
        window.open('https://www.youtube.com/channel/UCvv1VGOeNA4bmMq9fqU06_g', '_blank');
        return;
      case 'linkedin':
        window.open('https://www.linkedin.com/company/interimarket', '_blank');
        return;
    }
  }

  render() {
    return (
      <div style={this.styles.buttonContainer}>
        <FloatingActionButton backgroundColor="#3B5998" onTouchTap={() => this.onButtonClick('facebook')} mini={true} style={this.styles.button}>
          <FontIcon className="fa fa-facebook"/>
        </FloatingActionButton>
        <FloatingActionButton backgroundColor="#55ACEE" onTouchTap={() => this.onButtonClick('twitter')} mini={true} style={this.styles.button}>
          <FontIcon className="fa fa-twitter"/>
        </FloatingActionButton>
        <FloatingActionButton backgroundColor="#CD2121" onTouchTap={() => this.onButtonClick('youtube')} mini={true} style={this.styles.button}>
          <FontIcon className="fa fa-youtube-play"/>
        </FloatingActionButton>
        <FloatingActionButton backgroundColor="#0073B2" onTouchTap={() => this.onButtonClick('linkedin')} mini={true} style={this.styles.button}>
          <FontIcon className="fa fa-linkedin"/>
        </FloatingActionButton>
      </div>
    );
  }
}

export default SocialButtons;
