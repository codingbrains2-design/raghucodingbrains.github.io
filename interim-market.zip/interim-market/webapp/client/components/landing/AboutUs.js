import React from 'react';
import {} from 'material-ui';
import {Col, Row} from 'react-flexbox-grid';
import {brandColor} from 'Assets/theme/interimarket.theme';
import {Link} from 'react-scroll';
import TeamMember from './TeamMember';

class AboutUs extends React.Component {
  constructor(props) {
    super(props)
  }

  render() {
    return (
      <div>
        <Row center="xs">
          <h2 style={{marginTop: 35}}>About Us</h2>
        </Row>
        <Row style={{paddingBottom: 35}}>
          <Col xs={12} className="document">
            <div className="center-align">
              <p>We are expert in-house professionals with years of experience with in the industry.</p>
              <p>Our mission is to become "The Global hub" for all organisations and high value contractors.</p>
              <p>Our values are driven by Quality, Simplicity, Innovation and trust.</p>
              <p>We are changing the way organisations hire and manage contingent workforce.</p>
              <p>
                At InteriMarket, we believe that technology can help us reach far beyond the limitations of traditional
                recruiting, several third party costs and outdated management. We empower employers with the power of
                data and reporting, real-time analytics, direct access and great match making to high value talent and
                much more.
              </p>
              <p>
                Learn more about how it works&nbsp;
                <Link
                  to='how_it_works'
                  spy={true}
                  smooth="easeInOutQuint"
                  offset={-75}
                  style={{textDecoration: 'underline', color: '#FF851B', cursor: 'pointer'}}
                  duration={1000}>here.</Link>
              </p>
            </div>
            <Row className="center-align" style={{margin: '40px 0'}}>
              <Col xs={12}>
                <h2 style={{margin: '35px 0 50px'}}>Meet our team</h2>
              </Col>
              <Col xsOffset={2} xs={4}>
                <TeamMember name="Bhumika Zhaveri" avatar={require('Assets/images/about/bhu.jpg')}/>
              </Col>
              <Col xs={4}>
                <TeamMember name="Prashant Chamarty" avatar={require('Assets/images/about/pc.jpg')}/>
              </Col>
            </Row>
          </Col>
        </Row>
      </div>
    )
  }
}

export default AboutUs;
