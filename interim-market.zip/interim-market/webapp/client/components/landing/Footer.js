import React from 'react';
import {Link} from 'react-router';
import {FloatingActionButton} from 'material-ui';
import {NavigationArrowUpward} from 'material-ui/svg-icons/index';
import {overlayColor} from 'Assets/theme/interimarket.theme';
import {animateScroll} from 'react-scroll';

class Footer extends React.Component {
  constructor(props) {
    super(props)
  }

  get styles() {
    return {
      footerLinks: {
        color: '#C8543B',
        fontWeight: 300
      }
    }
  }

  render() {
    return (
      <footer style={{flex: 'none', position: 'relative'}}>
        <div className="center-align footer">
          <div style={{position: 'absolute', top: '-28px', left: 0, right: 0}}>
            <FloatingActionButton
              backgroundColor='#333333' style={{boxShadow: 'none'}}
              onTouchTap={() => animateScroll.scrollToTop()}
            >
              <NavigationArrowUpward style={{color: overlayColor, fill: overlayColor}}/>
            </FloatingActionButton>
          </div>
          <div className="footer-content">
            <p>InteriMarket Logos, site design & content &#9400; 2017 InteriMarket Ltd.</p>
            <p>All rights reserved.</p>
            <p>
              <Link style={this.styles.footerLinks} to="/terms-of-service">
                Terms of service
              </Link>
              <span style={this.styles.footerLinks}>  &middot;  </span>
              <Link style={this.styles.footerLinks} to="/privacy-policy">
                Privacy Policy
              </Link>
              <span style={this.styles.footerLinks}>  &middot;  </span>
              <Link style={this.styles.footerLinks} to="/contact-us">
                Contact Us
              </Link>
            </p>
          </div>
        </div>
      </footer>
    )
  }
}

export default Footer;
