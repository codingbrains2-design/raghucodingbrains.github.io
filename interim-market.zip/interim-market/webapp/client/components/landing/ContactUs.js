import React, {Component} from 'react';
import {Card, CardActions, CardText, CardTitle} from 'material-ui/Card';
import {RaisedButton, MenuItem, grey500, grey600} from 'material-ui';
import {FormsyText, FormsySelect} from 'formsy-material-ui/lib';
import {overlayColor, brandColor} from 'Assets/theme/interimarket.theme';
import {Col, Grid, Row} from 'react-flexbox-grid';
import SocialButtons from '../landing/SocialButtons';
import Footer from '../landing/Footer';

class ContactUs extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      canSubmit: false,
      formValid: false,
      showButton: false,
    }
  }

  get styles() {
    return {
      formTitle: {
        padding: '12px 16px 0px 16px',
      },
      formDescription: {
        padding: '0px 16px 16px 16px',
        fontWeight: 300,
        fontSize: '10px'
      },
      chooseButton: {
        cursor: 'pointer',
        position: 'absolute',
        top: 0,
        bottom: 0,
        right: 0,
        left: 0,
        width: '100%',
        opacity: 0
      }
    }
  }

  clearAttachment() {
    this.refs.ContactusAttachments.value = '';
    this.refs.chosenFiles.innerHTML = '<i style="color: #c6c6c6">No file Chosen</i>';
    this.setState({showButton: false});
    if (!this.state.formValid) {
      this.setFormValidity(false);
    }
  }

  onFileSelect(e) {
    if (e.target.files.length === 0) {
      this.refs.chosenFiles.innerHTML = '<i style="color: #c6c6c6">No file Chosen</i>';
      this.setState({showButton: false})
    }
    else {
      let text = e.target.files[0].name;
      this.refs.chosenFiles.innerHTML = text;
      this.setState({showButton: true});
    }
  }

  submitForm(data) {
    console.log(data);
    this.props.actions.submitContactUs(data);
    this.refs.form.reset();
  }

  setFormValidity(enabled) {
    this.setState({canSubmit: enabled, formValid: enabled});
  }

  render() {
    return (
      <div>
        <div className="main-content">
          <div style={{margin: '3% 0 10%'}}>
            <Grid>
              <div className="wrap">
                <Col xs={12}>
                  <Row center="xs" style={{marginTop: 15}}>
                    <h2>Contact Us</h2>
                  </Row>
                </Col>
                <Col xs={12}>
                    <Col xsOffset={2} mdOffset={1} xs={8} md={10}>
                      <Row center="xs">
                        <p className="lead" style={{margin: 0}}>Have a question, suggestion or 
                          comment on how InteriMarket can help you connect with the right people 
                          or organisations, drop us a note.</p>
                      </Row>
                      <Formsy.Form
                        ref="form"
                        onValid={() => this.setFormValidity(true)}
                        onInvalid={() => this.setFormValidity(false)}
                        onValidSubmit={(data) => this.submitForm(data)}
                      >
                        <Col xs={12} style={{marginTop: 15}}>
                          <CardText style={this.styles.formDescription}>
                            <FormsyText
                              style={{marginTop: 12}}
                              hintText="Name"
                              name="name"
                              fullWidth={true}
                              errorStyle={{float: 'left'}}
                              autoComplete="off"
                              required/>
                            <FormsyText
                              style={{marginTop: 12}}
                              hintText="Email ID"
                              name="email"
                              fullWidth={true}
                              validations="isEmail"
                              validationError="Not a valid email id"
                              errorStyle={{float: 'left'}}
                              autoComplete="off"
                              required/>
                            <FormsySelect
                              style={{marginTop: 12, float: 'left', textAlign: 'left'}}
                              name="query_type"
                              required
                              hintText="Select Query Type"
                              fullWidth={true}
                            >
                              <MenuItem value='Account and Security' primaryText="Account and Security"/>
                              <MenuItem value='Finding a Job' primaryText="Finding a Job"/>
                              <MenuItem value='Other' primaryText="Other"/>
                              <MenuItem value='Privacy/Abuse' primaryText="Privacy/Abuse"/>
                              <MenuItem value='Recruitment' primaryText="Recruitment"/>
                              <MenuItem value='Sales' primaryText="Sales"/>
                              <MenuItem value='Suggestion/Comment' primaryText="Suggestion/Comment"/>
                              <MenuItem value='Technical' primaryText="Technical"/>
                            </FormsySelect>
                            <FormsyText
                              style={{marginTop: 12}}
                              hintText="Description"
                              name="description"
                              fullWidth={true}
                              multiLine={true}
                              rows={2}
                              rowsMax={4}
                              errorStyle={{float: 'left'}}
                              autoComplete="off"
                              required/>
                          </CardText>
                          <CardActions style={{textAlign: 'left'}}>
                            <RaisedButton
                              containerElement="label"
                              primary={true}
                              label="Attachment">
                              <input ref="ContactusAttachments" type="file"
                                     style={this.styles.chooseButton}
                                     onChange={(e) => this.onFileSelect(e)}/>
                            </RaisedButton>
                            <em style={{paddingLeft: 5, fontSize: 11, color: '#c6c6c6'}} ref="chosenFiles">
                              No file chosen
                            </em>
                            {this.state.showButton ? (
                            <span style={{fontSize: 16, verticalAlign: 'middle', color: grey500, cursor: 'pointer'}}
                                  onTouchTap={() => this.clearAttachment()}>&#10005;</span>) : ''}
                          </CardActions>
                          <CardActions >
                            <RaisedButton
                              label="Submit"
                              type="submit"
                              labelStyle={{fontSize: 11}}
                              secondary={true}
                              fullWidth={true}
                              disabled={!this.state.canSubmit}
                            />
                          </CardActions>
                        </Col>
                      </Formsy.Form>
                    </Col>
                </Col>
              </div>
            </Grid>
          </div>
        </div>
        <Footer parentProps={this.props}/>
        <SocialButtons />
      </div>
    );
  }
}

export default ContactUs;
