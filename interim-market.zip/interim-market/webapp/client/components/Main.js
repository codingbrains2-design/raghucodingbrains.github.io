import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import muiTheme from 'Assets/theme/interimarket.theme';
import initLinkedinApi from '../store/configureLinkedinApi';
import * as globalActions from 'Actions/global';
import Navbar from './Navbar';
import {Snackbar} from 'material-ui';

class Main extends React.Component {
  constructor(props) {
    super(props);
  }

  componentWillMount() {
    initLinkedinApi();

    window.onLinkedInLoad = function () {
      const getProfileData = () => {
        console.log(IN.User.isAuthorized());
        console.log(IN.ENV.auth.oauth_token);
        IN.API.Raw('/people/~:(id,num-connections,picture-url,headline,specialties,site-standard-profile-request,industry,email-address,public-profile-url,location:(name),positions:(title,start-date,end-date,is-current,company))')
          .result((data) => {
            console.log(data)
          })
          .error((error) => {
            console.log(error)
          });
      };

      IN.Event.on(IN, 'auth', getProfileData);
    }
  }

  render() {
    return (
      <MuiThemeProvider muiTheme={muiTheme}>
        <div>
          <Navbar parentProps={this.props}/>
          {React.cloneElement(this.props.children, this.props)}
          <Snackbar
            open={this.props.snackbar.open}
            message={this.props.snackbar.text}
            autoHideDuration={4000}
            onRequestClose={() => this.props.actions.toggleSnackbar()}
          />
        </div>
      </MuiThemeProvider>
    );
  }
}

function mapStateToProps(state) {
  return {
    snackbar: state.snackbar
  }
}

function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({...globalActions}, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Main);
