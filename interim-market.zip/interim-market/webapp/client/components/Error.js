import React, {Component} from 'react';
import {overlayColor, brandColor} from 'Assets/theme/interimarket.theme';
import {Col, Grid, Row} from 'react-flexbox-grid';
import {Divider} from 'material-ui';
import Footer from './landing/Footer';

class Error extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div>
        <div className="main-content">
          <div className="wrap">
            <div style={{margin: '6% 0'}}>
              <Row center="xs">
                <Col xs={7}>
                  <h2>Page not found</h2>
                  <Divider/>
                  <h1>Oops!</h1>
                  <h2>We can't seem to find the page you are looking for.</h2>
                  <div className="error-404">404</div>
                </Col>
              </Row>
            </div>
          </div>
        </div>
        <Footer parentProps={this.props}/>
      </div>
    )
  }
}

export default Error;
